class CowboyClientError(Exception):
    pass


class CowboyConfigError(Exception):
    """
    Errors with user config
    """

    pass
