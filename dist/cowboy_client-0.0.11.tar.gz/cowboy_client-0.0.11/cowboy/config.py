# API_ENDPOINT = "http://127.0.0.1:3000"

API_ENDPOINT = "http://18.223.150.134:3000"
TASK_ENDPOINT = f"{API_ENDPOINT}/task/get"

SAD_KIRBY = "૮₍˶Ó﹏Ò ⑅₎ა"
REPO_ROOT = "repos"

USER_CONFIG = ".user"

HB_PATH = ".heartbeat"
HB_INTERVAL = 2
